var mainState = {
    preload: function() { 
        // This function will be executed at the beginning     
        // That's where we load the images and sounds 
        game.load.spritesheet('player', 'assets/images/player.png', 108, 140, 16);
        game.load.spritesheet('monster', 'assets/images/monster.png', 115, 90, 4);
    	game.load.image('tile1', 'assets/images/ground1.png');
    	game.load.image('tile2', 'assets/images/ground2.png');
    	game.load.image('tile3', 'assets/images/ground3.png');
    	game.load.image('tile4', 'assets/images/ground4.png');
    	game.load.image('tile5', 'assets/images/ground5.png');
    	game.load.image('tile6', 'assets/images/ground6.png');
    	game.load.image('tile7', 'assets/images/ground7.png');
    	game.load.image('bkg1', 'assets/images/bkg1.png');
    	game.load.image('bkg2', 'assets/images/bkg2.png');
    	game.load.image('bkg3', 'assets/images/bkg3.png');
    	game.load.image('bkg4', 'assets/images/bkg4.png');
    	game.load.image('bkg5', 'assets/images/bkg5.png');
    	game.load.image('bkg6', 'assets/images/bkg6.gif');
    	game.load.audio('game_over', 'assets/audio/game_over.mp3');
    	game.load.audio('jump', 'assets/audio/jump.wav');
    },

    create: function() { 
        // This function is called after the preload function     
        // Here we set up the game, display sprites, etc.  
    	// game.stage.backgroundColor = "#abdcfb";
    	//here we add two tile sprites with parameters(locationX, locationY, width, height, key)
        var rand = Math.floor((Math.random() * 6) + 1);
        switch(rand) {
        	case 1:
        		this.bkg = game.add.tileSprite(0, 0, game.width, game.height, 'bkg1');
        		break;
        	case 2:
    	    	this.bkg = game.add.tileSprite(0, 0, game.width, game.height, 'bkg2');
        		break;
        	case 3:
    	    	this.bkg = game.add.tileSprite(0, 0, game.width, game.height, 'bkg3');
        	 	break;
        	case 4:
        		this.bkg = game.add.tileSprite(0, 0, game.width, game.height, 'bkg4');
        		break;
        	case 5:
        		this.bkg = game.add.tileSprite(0, 0, game.width, game.height, 'bkg5');
        		break;
    		case 6:
    			this.bkg = game.add.tileSprite(0, 0, game.width, game.height, 'bkg6');
    		break;
        	default:
    	    	this.bkg = game.add.tileSprite(0, 0, game.width, game.height, 'bkg1');
        		break;
        }
        
	    //add and animate player
		this.player = game.add.sprite(0, 0, 'player');
		game.physics.enable(this.player);
		this.player.body.collideWorldBounds = true;
		this.player.body.gravity.y = 1000;
		this.player.body.bounce.y = 0.1;
    	hmove = 200;
		vmove = -300;
		jumpTimer = 0;

		//animate sprite walking
		this.player.animations.add('right', [0, 1, 2, 3, 4, 5, 6, 7], 10, true);
		this.player.animations.add('left', [15, 14, 13, 12, 11, 10, 9, 8], 10, true);
		
		//resize visible sprite size
		this.player.scale.x = 0.45;
		this.player.scale.y = 0.45;

		//resize sprite hitbox setSize(width, height, offsetX, offsetY)
		this.player.body.setSize(25,90,50,15);

		//add and animate monster
		var randMonster = Math.floor((Math.random() * 6) + 1);
		
		this.monster = game.add.sprite(0, 0, 'monster');
		game.physics.enable(this.monster);
		this.monster.body.collideWorldBounds = true;
		this.monster.body.gravity.y = 300;
		this.monster.body.bounce.y = 0.5;

		//animate monster
		this.monster.animations.add('fly', [0, 1, 2, 3], 10, true);

		//resize sprite hitbox setSize(width, height, offsetX, offsetY)
		this.monster.body.setSize(95,175,0,0);
		//start physics system
		game.physics.startSystem(Phaser.Physics.ARCADE);
		game.camera.follow(this.player);

		this.tileScale = 0.85;
		this.tileHeight = 70*this.tileScale;
		this.tileWidth = 70*this.tileScale;

		//create an empty group
		this.platforms = game.add.group();
	    this.platforms.enableBody = true;
	    this.initPlatforms();
		game.world.bringToTop(this.player); 
		game.physics.arcade.checkCollision.right = false;
		game.physics.arcade.checkCollision.bottom = false;

		score = 0;
		scoreLabel = game.add.text(16, 34, ' ', {font: '22px Roboto', fill: '#151515'});
    	scoreLabel.visible = false;

    	jumpSound = game.add.audio('jump');
    	startSound = game.add.audio('game_over');
    	startSound.play();
		this.timer = game.time.events.loop(1500, this.addPlatforms, this);
    	
    	//show controls
    	controlsLabel = game.add.text(game.world.centerX, game.world.centerY, 'press『space』to jump', {font: '24px Roboto', fill: '#151515'});
		controlsLabel.anchor.setTo(0.5, 0.5);

		//fade controls
    	game.time.events.add(3000, function() {
    	    game.add.tween(controlsLabel).to({y: 0}, 1500, Phaser.Easing.Linear.None, true);    
    	    game.add.tween(controlsLabel).to({alpha: 0}, 1500, Phaser.Easing.Linear.None, true);
    	}, this);
    },
 	
 	update: function() {
    	this.checkTileOutOfBounds();
    	this.bkg.tilePosition.x -= 1;
    	this.game.physics.arcade.collide(this.player, this.platforms);
    	this.game.physics.arcade.collide(this.monster, this.player, this.collisionHandler(), null, this);


    	//scoring
    	if(this.monster.body.onFloor()) {
    		scoreLabel.visible = true;
    	}
    	scoreLabel.anchor.setTo(0, 0.5);
		scoreLabel.setText('score: ' + score);

        // This function is called 60 times per second    
        // It contains the game's logic   

		this.player.body.velocity.x = 0;
		// this.player.body.velocity.y = 0;
		// game.debug.bodyInfo(this.player, 16, 24);
	  
	 //    //show sprite hitbox
	    // game.debug.body(this.player);
	    // game.debug.body(this.monster);
		
		this.monster.animations.play('fly');
		this.monster.body.velocity.x = -450; 
	   	this.monster.body.immovable = true;
		//movement
		// if(game.input.keyboard.isDown(Phaser.Keyboard.LEFT)) {
		// 	this.player.body.velocity.x = -hmove;
		// 	this.player.animations.play('left');
		// }

		// else if(game.input.keyboard.isDown(Phaser.Keyboard.RIGHT)) {
		// 	this.player.body.velocity.x = hmove;
		// 	this.player.animations.play('right');	
		// }

		// if(game.input.keyboard.isDown(Phaser.Keyboard.RIGHT)) {
			this.player.body.velocity.x = hmove;
			this.player.animations.play('right');
			
		// }

		if(game.input.keyboard.isDown(Phaser.Keyboard.SPACEBAR)) {
			if(this.player.body.touching.down && jumpTimer === 0) {
				jumpTimer = 1;
				this.player.body.velocity.y = vmove;
				jumpSound.play();
			} 
			else if(jumpTimer > 0 && jumpTimer < 31) {
				jumpTimer++;
				this.player.body.velocity.y = vmove + (jumpTimer * 8);
			}
		}
		else {
			jumpTimer = 0;
		}
		
		if(this.player.body.onFloor()) {
			this.gameOver();
		}
    },

    addTile: function(x, y, tileType) {
	    // Create a tile at the position x and y
	    var tile; 
	    switch(tileType){
	    	case 1:
	    		tile = game.add.sprite(x, y, 'tile1');
	    		break;
	    	case 2:
	    		tile = game.add.sprite(x, y, 'tile2');
	    		break;
	    	case 3:
	    		tile = game.add.sprite(x, y, 'tile3');
	    		break;
	    	case 4:
	    		tile = game.add.sprite(x, y, 'tile4');
	    		break;
	    	case 5:
	    		tile = game.add.sprite(x, y, 'tile5');
	    		break;
	    	case 6:
	    		tile = game.add.sprite(x, y, 'tile6');
	    		break;
    		case 7:
    			tile = game.add.sprite(x, y, 'tile7');
    			break;
	    	default:
	    		tile = game.add.sprite(x, y, 'tile1');
	    		break;
	    }
	    
	    // Add the tile to our previously created group
	    this.platforms.add(tile);

	    // Enable physics on the tile 
	    game.physics.arcade.enable(tile);

	    // Add velocity to the tile to make it move left
	    tile.body.velocity.x = -450; 
	   	tile.body.immovable = true;
	    // Automatically kill the tile when it's no longer visible 
	    tile.checkWorldBounds = true;
	    // tile.outOfBoundsKill = true;
		
	    tile.scale.x = this.tileScale;
	    tile.scale.y = this.tileScale;
	},

	addPlatforms: function() {
		score+=1;
	    var consecutiveTiles = game.rnd.integerInRange(2, 10);
	    //Math.floor((Math.random() * 10) + 1); random from 1 to 10

	    //lower has a greater value in this case
	    var lower = Math.floor(game.height - this.tileHeight);
	    var upper = 400-Math.floor(this.player.world.y - (this.player.height*0.75));
	    var platformPos = Math.floor((Math.random() * lower) + upper);
	    var tileType = Math.floor((Math.random() * 7)+1);
	    	
	    for(var i = 0; i < consecutiveTiles; i++) {
	    	this.addTile(game.width+(i*this.tileWidth), game.height - this.tileHeight, tileType);
	    }
	},

	initPlatforms: function() {
    	var consecutiveTiles = game.rnd.integerInRange(20, 25);
	    var platformPos = Math.floor(game.height - this.tileHeight);
	    var tileType = Math.floor((Math.random() * 7)+1);
	    for(var i = 0; i < consecutiveTiles; i++) {
	    	this.addTile((this.tileWidth * 4) + i * this.tileWidth, platformPos, tileType);
	    }  
	},

	checkTileOutOfBounds: function() {
		for (var i = 0; i < this.platforms.children.length; i++) {
			var curr = this.platforms.children[i];
			if(curr.x < 0 - this.tileWidth) {
				curr.kill();
				curr.destroy();
				this.platforms.remove(curr);
			}
		}
	},

	restartGame: function() {
		// Start the 'main' state, which restarts the game
    	game.state.start('main');
	},

	collisionHandler: function() {
		if(this.player.body.touching.down) {
			// if(this.monster.overlap(this.player)) {
			// 	this.gameOver();
			// }
			if(this.game.physics.arcade.collide(this.monster, this.player)) {
				this.gameOver();
			}
		}
	},

	gameOver: function() {
		controlsLabel.visible = false;
		scoreLabel.visible = false;
		var gameoverLabel = game.add.text(game.world.centerX, game.world.centerY-100, ' ', {font: '184px Roboto', fill: '#151515'});
		gameoverLabel.anchor.setTo(0.5, 0.5);
		gameoverLabel.setText("『GAME OVER』");

		if(score >= highScore) {
			highScore = score;
		}
	
		yourScoreLabel = game.add.text(game.world.centerX, game.world.centerY, 'YOUR SCORE: ' + score, {font: '24px Roboto', fill: '#151515'});
		yourScoreLabel.anchor.setTo(0.5, 0.5);

		highScoreLabel = game.add.text(game.world.centerX, game.world.centerY+30, 'HIGH SCORE: ' + highScore, {font: '25px Roboto', fill: '#151515'});
		highScoreLabel.anchor.setTo(0.5, 0.5);

		anyKeyLabel = game.add.text(game.world.centerX, game.world.centerY+60, '『CLICK TO RESTART』', {font: '25px Roboto', fill: '#151515'});
		anyKeyLabel.anchor.setTo(0.5, 0.5);

		this.pauseButton = this.game.add.sprite(game.world.centerX, game.height-100);
		this.pauseButton.inputEnabled = true;
		this.game.paused = true;
		this.game.input.onDown.add(function () {
			if(this.game.paused){
				this.game.paused = false;
				this.restartGame();
			}
		},this);
	},

};

var game = new Phaser.Game(1300, 400, Phaser.AUTO, 'game');
// Add the 'mainState' and call it 'main'
highScore = 0;
game.state.add('main', mainState);
// Start the state to actually start the game
game.state.start('main');